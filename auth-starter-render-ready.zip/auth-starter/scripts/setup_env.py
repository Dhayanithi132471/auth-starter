"""Generate local development secrets without overwriting existing settings."""
from pathlib import Path
import os
import secrets


def main():
    root = Path(__file__).resolve().parents[1]
    target = root / ".env"
    password = secrets.token_hex(24)
    content = (root / ".env.example").read_text()
    content = content.replace("generate-with-setup-script", password)
    content = content.replace(f"JWT_SECRET={password}", f"JWT_SECRET={secrets.token_hex(32)}")
    try:
        fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        print(".env already exists; kept existing settings.")
        return
    with os.fdopen(fd, "w") as stream:
        stream.write(content)
    print("Created .env with random database and JWT secrets.")


if __name__ == "__main__":
    main()
