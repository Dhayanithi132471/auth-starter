import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api } from './api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');

  const reload = useCallback(async () => {
    setLoading(true);
    setLoadError('');
    try {
      setSession(await api.me());
    } catch (error) {
      if (error.status === 401) setSession(null);
      else setLoadError(error.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void reload(); }, [reload]);

  useEffect(() => {
    if (!session) return;
    const milliseconds = new Date(session.expires_at).getTime() - Date.now();
    const timeout = window.setTimeout(() => setSession(null), Math.max(0, milliseconds));
    return () => window.clearTimeout(timeout);
  }, [session]);

  const value = useMemo(() => ({
    session, loading, loadError, reload,
    login: async (credentials) => setSession(await api.login(credentials)),
    register: async (details) => setSession(await api.register(details)),
    logout: async () => {
      // Keep the session visible if revocation failed so the user can retry.
      await api.logout();
      setSession(null);
    },
    clearSession: () => setSession(null),
  }), [session, loading, loadError, reload]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const auth = useContext(AuthContext);
  if (!auth) throw new Error('useAuth must be used inside AuthProvider');
  return auth;
}
