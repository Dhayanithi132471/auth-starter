import { useEffect, useRef, useState } from 'react';
import { Link, Navigate, Route, Routes, useNavigate } from 'react-router-dom';
import { api } from './api';
import { useAuth } from './AuthContext';

function Mark({ small = false }) {
  return <span className={`brand ${small ? 'brand-dark' : ''}`}><span className="brand-mark" aria-hidden="true">h</span>haven<span className="brand-dot">.</span></span>;
}

function Arrow() {
  return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 12h15m-6-6 6 6-6 6" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}

function Shield() {
  return <svg width="18" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 3 4 6v6c0 4 8 9 8 9s8-5 8-9V6l-8-3Z" stroke="currentColor" strokeWidth="1.6" /><path d="m8 12 3 3 5-6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}

function AuthLayout({ children }) {
  return <main className="auth-shell">
    <aside className="story-panel">
      <Mark />
      <div className="story-copy">
        <span className="eyebrow"><span className="tiny-star">✳</span> A LITTLE SPACE FOR YOU</span>
        <h1>Good things<br />start <em>here.</em></h1>
        <p>A place to pick up where you left off.<br />Make yourself at home.</p>
      </div>
      <div className="arch-art" aria-hidden="true"><div className="arch arch-one" /><div className="arch arch-two" /><div className="arch arch-three" /><div className="art-sun" /><div className="art-line" /></div>
      <div className="story-footer"><span>YOUR ACCOUNT. YOUR SPACE.</span><span>EST. 2026</span></div>
    </aside>
    <section className="form-panel">
      <div className="mobile-brand"><Mark small /></div>
      {children}
      <p className="form-footer"><Shield /> A secure place to get started.</p>
    </section>
  </main>;
}

function PasswordField({ id = 'password', label = 'Password', value, onChange, isNew = false, hint }) {
  const [visible, setVisible] = useState(false);
  return <div className="field">
    <label htmlFor={id}>{label}</label>
    <div className="password-wrap">
      <input id={id} name={id} type={visible ? 'text' : 'password'} value={value} onChange={onChange}
        autoComplete={isNew ? 'new-password' : 'current-password'} required minLength={isNew ? 12 : 1} maxLength={128}
        aria-describedby={hint ? `${id}-hint` : undefined} placeholder={isNew ? 'Create a strong password' : 'Enter your password'} />
      <button type="button" className="show-password" aria-label={visible ? `Hide ${label.toLowerCase()}` : `Show ${label.toLowerCase()}`} aria-pressed={visible} onClick={() => setVisible(!visible)}>{visible ? 'Hide' : 'Show'}</button>
    </div>
    {hint && <small id={`${id}-hint`}>{hint}</small>}
  </div>;
}

function AuthForm({ mode }) {
  const register = mode === 'register';
  const auth = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const errorRef = useRef(null);

  useEffect(() => {
    document.title = `${register ? 'Create an account' : 'Welcome back'} — Haven`;
  }, [register]);
  useEffect(() => { if (error) errorRef.current?.focus(); }, [error]);

  if (auth.session) return <Navigate to="/dashboard" replace />;

  async function submit(event) {
    event.preventDefault();
    if (busy) return;
    setError('');
    if (register && !name.trim()) { setError('Please enter your name.'); return; }
    if (register && password !== confirm) { setError('Your passwords do not match.'); return; }
    setBusy(true);
    try {
      const credentials = { email: email.trim(), password };
      if (register) await auth.register({ ...credentials, name: name.trim() });
      else await auth.login(credentials);
      navigate('/dashboard', { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return <AuthLayout><div className="form-content">
    <div className="section-number">{register ? '02 / GET STARTED' : '01 / WELCOME HOME'}</div>
    <h2>{register ? 'Make it yours.' : 'Welcome back.'}</h2>
    <p className="subtitle">{register ? 'A fresh start is just a few details away.' : 'Sign in and settle into your space.'}</p>
    <div className="auth-tabs" aria-label="Account options">
      <Link to="/login" className={!register ? 'active' : ''} aria-current={!register ? 'page' : undefined}>Sign in</Link>
      <Link to="/register" className={register ? 'active' : ''} aria-current={register ? 'page' : undefined}>Create account</Link>
    </div>
    <form onSubmit={submit} aria-busy={busy}>
      {error && <div className="error-message" role="alert" tabIndex={-1} ref={errorRef}>{error}</div>}
      <fieldset disabled={busy}>
        {register && <div className="field"><label htmlFor="name">Your name</label><input id="name" name="name" autoComplete="name" placeholder="Alex Morgan" value={name} onChange={(e) => setName(e.target.value)} required maxLength={80} /></div>}
        <div className="field"><label htmlFor="email">Email address</label><input id="email" name="email" type="email" autoComplete="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} required maxLength={254} /></div>
        <PasswordField value={password} onChange={(e) => setPassword(e.target.value)} isNew={register} hint={register ? 'Use 12–128 characters. A memorable passphrase works well.' : undefined} />
        {register && <PasswordField id="confirm-password" label="Confirm password" value={confirm} onChange={(e) => setConfirm(e.target.value)} isNew />}
        <button className="primary-button" type="submit">{busy ? 'One moment…' : register ? 'Create my account' : 'Sign in'}{busy ? <span className="spinner" /> : <Arrow />}</button>
      </fieldset>
    </form>
    <p className="switch-prompt">{register ? 'Already have an account?' : 'New around here?'} <Link to={register ? '/login' : '/register'}>{register ? 'Sign in' : 'Create an account'}</Link></p>
  </div></AuthLayout>;
}

function Dashboard() {
  const { session, logout, clearSession } = useAuth();
  const [busy, setBusy] = useState(false);
  const [checking, setChecking] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  useEffect(() => { document.title = 'Your space — Haven'; }, []);
  if (!session) return <Navigate to="/login" replace />;
  const { user, expires_at: expiresAt } = session;

  async function signOut() {
    setBusy(true);
    setError('');
    try { await logout(); } catch (err) { setError(err.message); } finally { setBusy(false); }
  }

  async function checkAccess() {
    setChecking(true);
    setError('');
    setMessage('');
    try { setMessage((await api.private()).message); }
    catch (err) { if (err.status === 401) clearSession(); else setError(err.message); }
    finally { setChecking(false); }
  }

  return <div className="dashboard">
    <header className="dashboard-header"><Mark small /><div className="header-account"><span>{user.email}</span><button className="quiet-button" onClick={signOut} disabled={busy}>{busy ? 'Signing out…' : 'Sign out'} <Arrow /></button></div></header>
    <main className="dashboard-main">
      <div className="dashboard-intro"><span className="eyebrow">YOUR PERSONAL SPACE</span><h1>You're right at home,<br /><em>{user.name}.</em></h1><p>Your account is ready. This is your place to begin.</p></div>
      {error && <div className="error-message" role="alert">{error}</div>}
      <div className="dashboard-grid">
        <section className="profile-card"><span className="card-kicker">01 / YOUR PROFILE</span><div className="avatar" aria-hidden="true">{Array.from(user.name)[0]?.toUpperCase()}</div><h2>{user.name}</h2><p>{user.email}</p><dl><div><dt>Joined</dt><dd>{new Date(user.created_at).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}</dd></div><div><dt>Status</dt><dd className="status"><span />Signed in</dd></div></dl></section>
        <section className="session-card"><span className="card-kicker">02 / PEACE OF MIND</span><div className="shield-circle"><Shield /></div><h2>You're securely signed in.</h2><p>Your session ends at {new Date(expiresAt).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}. You can sign in again whenever you're ready.</p><button className="primary-button" onClick={checkAccess} disabled={checking}>{checking ? 'Checking…' : 'Check my access'}<Arrow /></button><p className="access-result" role="status">{message}</p></section>
      </div>
      <footer className="dashboard-footer">A little space. A fresh start. <span>HAVEN.</span></footer>
    </main>
  </div>;
}

export default function App() {
  const { loading, loadError, reload } = useAuth();
  if (loading || loadError) return <main className="loading-page"><Mark small />{loading ? <p role="status">Getting your space ready…</p> : <div className="connection-error"><p role="alert">{loadError}</p><button className="primary-button" onClick={reload}>Try again <Arrow /></button></div>}</main>;
  return <Routes>
    <Route path="/login" element={<AuthForm key="login" mode="login" />} />
    <Route path="/register" element={<AuthForm key="register" mode="register" />} />
    <Route path="/dashboard" element={<Dashboard />} />
    <Route path="*" element={<Navigate to="/dashboard" replace />} />
  </Routes>;
}
