export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

export async function request(path, { method = 'GET', body, signal } = {}) {
  let response;
  try {
    const apiBase = import.meta.env.VITE_API_URL || '';
    response = await fetch(`${apiBase}/api${path}`, {
      method,
      credentials: 'include',
      signal,
      headers: {
        ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        ...(!['GET', 'HEAD', 'OPTIONS'].includes(method) ? { 'X-CSRF-Protection': '1' } : {}),
      },
      ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
    });
  } catch (error) {
    if (error.name === 'AbortError') throw error;
    throw new ApiError('Unable to reach the server. Please check your connection and try again.', 0);
  }
  const data = response.status === 204 ? null : await response.json().catch(() => null);
  if (!response.ok) {
    let message = 'Something went wrong. Please try again.';
    if (typeof data?.detail === 'string') message = data.detail;
    if (Array.isArray(data?.detail)) {
      message = data.detail.map((item) => `${item.loc?.at(-1) || 'Field'}: ${item.msg}`).join('. ');
    }
    if (response.status === 429) {
      const seconds = Number(response.headers.get('Retry-After'));
      if (seconds > 0) message = `Too many attempts. Try again in ${Math.ceil(seconds / 60)} minute(s).`;
    }
    throw new ApiError(message, response.status);
  }
  if (response.status !== 204 && data === null) {
    throw new ApiError('The server returned an unexpected response. Please try again.', response.status);
  }
  return data;
}

export const api = {
  me: () => request('/auth/me'),
  login: (body) => request('/auth/login', { method: 'POST', body }),
  register: (body) => request('/auth/register', { method: 'POST', body }),
  logout: () => request('/auth/logout', { method: 'POST' }),
  private: () => request('/private'),
};
