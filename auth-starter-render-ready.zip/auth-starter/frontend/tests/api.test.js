import { afterEach, test } from 'node:test';
import assert from 'node:assert/strict';
import { api, ApiError } from '../src/api.js';

const originalFetch = globalThis.fetch;
afterEach(() => { globalThis.fetch = originalFetch; });

test('login sends cookies, JSON credentials, and the CSRF custom header', async () => {
  globalThis.fetch = async (url, options) => {
    assert.equal(url, '/api/auth/login');
    assert.equal(options.method, 'POST');
    assert.equal(options.credentials, 'include');
    assert.equal(options.headers['X-CSRF-Protection'], '1');
    assert.equal(options.headers['Content-Type'], 'application/json');
    assert.deepEqual(JSON.parse(options.body), { email: 'alex@example.com', password: 'keep exact spaces ' });
    return Response.json({ user: { name: 'Alex' }, expires_at: '2027-01-01T00:00:00Z' });
  };
  assert.equal((await api.login({ email: 'alex@example.com', password: 'keep exact spaces ' })).user.name, 'Alex');
});

test('registration uses the register endpoint and sends the name', async () => {
  globalThis.fetch = async (url, options) => {
    assert.equal(url, '/api/auth/register');
    assert.equal(JSON.parse(options.body).name, 'Alex');
    assert.equal(options.headers['X-CSRF-Protection'], '1');
    return Response.json({ user: { name: 'Alex' } }, { status: 201 });
  };
  assert.equal((await api.register({ name: 'Alex' })).user.name, 'Alex');
});

test('session lookup sends credentials without a request body', async () => {
  globalThis.fetch = async (url, options) => {
    assert.equal(url, '/api/auth/me');
    assert.equal(options.credentials, 'include');
    assert.equal(options.body, undefined);
    assert.equal(options.headers['X-CSRF-Protection'], undefined);
    return Response.json({ user: { id: 'id' } });
  };
  assert.equal((await api.me()).user.id, 'id');
});

test('logout accepts an empty 204 response and sends CSRF protection', async () => {
  globalThis.fetch = async (url, options) => {
    assert.equal(url, '/api/auth/logout');
    assert.equal(options.headers['X-CSRF-Protection'], '1');
    return new Response(null, { status: 204 });
  };
  assert.equal(await api.logout(), null);
});

test('authentication errors preserve status for session handling', async () => {
  globalThis.fetch = async () => Response.json({ detail: 'Please sign in.' }, { status: 401 });
  await assert.rejects(api.private(), (error) => error instanceof ApiError && error.status === 401 && error.message === 'Please sign in.');
});

test('validation errors identify the field', async () => {
  globalThis.fetch = async () => Response.json({ detail: [{ loc: ['body', 'email'], msg: 'Invalid email' }] }, { status: 422 });
  await assert.rejects(api.register({}), { message: 'email: Invalid email' });
});

test('rate limits display a useful retry delay', async () => {
  globalThis.fetch = async () => Response.json({ detail: 'Too many attempts' }, { status: 429, headers: { 'Retry-After': '61' } });
  await assert.rejects(api.login({}), { status: 429, message: 'Too many attempts. Try again in 2 minute(s).' });
});

test('connection failures offer a retry message', async () => {
  globalThis.fetch = async () => { throw new TypeError('fetch failed'); };
  await assert.rejects(api.me(), (error) => error.status === 0 && error.message.includes('Unable to reach the server'));
});

test('HTML proxy errors do not leak raw HTML into the page', async () => {
  globalThis.fetch = async () => new Response('<html>Bad gateway</html>', { status: 502 });
  await assert.rejects(api.me(), { status: 502, message: 'Something went wrong. Please try again.' });
});

test('an unexpected successful HTML response is rejected', async () => {
  globalThis.fetch = async () => new Response('<html>SPA fallback</html>', { status: 200 });
  await assert.rejects(api.me(), /unexpected response/);
});
