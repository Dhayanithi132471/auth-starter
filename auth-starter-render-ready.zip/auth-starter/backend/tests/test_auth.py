from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from uuid import uuid4

import jwt
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.config import get_settings
from app import rate_limit
from app.main import app
from app.models import AuthSession, User
from app.security import COOKIE_NAME, password_hash


def credentials(account):
    return {key: account[key] for key in ("email", "password")}


def set_cookie(client, value):
    client.cookies.clear()
    client.cookies.set(COOKIE_NAME, value, path="/api")


def test_register_persists_only_a_password_hash(client, db, account):
    response = client.post("/api/auth/register", json=account)
    assert response.status_code == 201
    body = response.json()
    assert body["user"]["email"] == account["email"]
    assert "password" not in response.text and "token" not in body
    user = db.scalar(select(User))
    assert user.password_hash != account["password"]
    assert user.password_hash.startswith("$argon2id$")
    assert password_hash.verify(account["password"], user.password_hash)
    assert client.get("/api/auth/me").status_code == 200
    assert client.get("/api/private").status_code == 200


def test_cookie_and_response_headers(client, account):
    response = client.post("/api/auth/register", json=account)
    cookie = response.headers["set-cookie"].lower()
    assert "httponly" in cookie and "samesite=lax" in cookie and "path=/api" in cookie
    assert response.headers["cache-control"] == "no-store"


def test_secure_cookie_setting(client, account, monkeypatch):
    monkeypatch.setattr(get_settings(), "cookie_secure", True)
    response = client.post("/api/auth/register", json=account)
    assert "; secure" in response.headers["set-cookie"].lower()


def test_email_normalization_and_duplicate_rejection(client, account):
    first = client.post("/api/auth/register", json={**account, "email": " ALEX@EXAMPLE.COM "})
    assert first.status_code == 201
    assert first.json()["user"]["email"] == "alex@example.com"
    assert client.post("/api/auth/register", json=account).status_code == 409
    client.post("/api/auth/logout")
    assert client.post("/api/auth/login", json={**credentials(account), "email": "ALEX@example.com"}).status_code == 200


def test_concurrent_duplicate_registration(account):
    def register(_):
        with TestClient(app, headers={"X-CSRF-Protection": "1"}) as other:
            return other.post("/api/auth/register", json=account).status_code
    with ThreadPoolExecutor(max_workers=2) as executor:
        results = list(executor.map(register, range(2)))
    assert sorted(results) == [201, 409]


def test_bad_credentials_have_same_error(client, account):
    client.post("/api/auth/register", json=account)
    wrong = client.post("/api/auth/login", json={**credentials(account), "password": "wrong"})
    missing = client.post("/api/auth/login", json={**credentials(account), "email": "missing@example.com"})
    assert wrong.status_code == missing.status_code == 401
    assert wrong.json() == missing.json()


def test_logout_revokes_jwt_and_login_starts_new_session(client, account):
    client.post("/api/auth/register", json=account)
    old_token = client.cookies.get(COOKIE_NAME)
    assert client.post("/api/auth/logout").status_code == 204
    assert client.get("/api/auth/me").status_code == 401
    set_cookie(client, old_token)
    assert client.get("/api/private").status_code == 401
    assert client.post("/api/auth/login", json=credentials(account)).status_code == 200
    # The test cookie has no domain; clear it before using the new server cookie.
    token = next(cookie.value for cookie in client.cookies.jar if cookie.domain)
    set_cookie(client, token)
    assert client.get("/api/auth/me").status_code == 200


def test_login_replaces_the_existing_browser_session(client, account):
    client.post("/api/auth/register", json=account)
    old_token = client.cookies.get(COOKIE_NAME)
    assert client.post("/api/auth/login", json=credentials(account)).status_code == 200
    set_cookie(client, old_token)
    assert client.get("/api/auth/me").status_code == 401


def test_logout_is_idempotent(client):
    assert client.post("/api/auth/logout").status_code == 204
    assert client.post("/api/auth/logout").status_code == 204


def test_no_cookie_is_unauthorized(client):
    assert client.get("/api/auth/me").status_code == 401
    assert client.get("/api/private").status_code == 401


def test_tampered_token_is_unauthorized(client, account):
    client.post("/api/auth/register", json=account)
    token = client.cookies.get(COOKIE_NAME)
    header, payload, signature = token.split(".")
    signature = ("A" if signature[0] != "A" else "B") + signature[1:]
    set_cookie(client, f"{header}.{payload}.{signature}")
    assert client.get("/api/auth/me").status_code == 401


@pytest.mark.parametrize("change", ["expired", "audience", "issuer", "type", "missing-exp", "bad-subject", "unknown-session", "algorithm", "other-user"])
def test_invalid_claims_are_rejected(client, account, change):
    client.post("/api/auth/register", json=account)
    settings = get_settings()
    claims = jwt.decode(client.cookies.get(COOKIE_NAME), settings.jwt_secret, algorithms=["HS256"], audience=settings.jwt_audience)
    if change == "expired": claims["exp"] = int((datetime.now(timezone.utc) - timedelta(minutes=1)).timestamp())
    if change == "audience": claims["aud"] = "other-app"
    if change == "issuer": claims["iss"] = "other-issuer"
    if change == "type": claims["type"] = "refresh"
    if change == "missing-exp": del claims["exp"]
    if change == "bad-subject": claims["sub"] = "not-a-uuid"
    if change == "unknown-session": claims["jti"] = str(uuid4())
    if change == "other-user": claims["sub"] = str(uuid4())
    algorithm = "HS384" if change == "algorithm" else "HS256"
    set_cookie(client, jwt.encode(claims, settings.jwt_secret, algorithm=algorithm))
    assert client.get("/api/auth/me").status_code == 401


def test_expired_database_session_is_rejected(client, db, account):
    client.post("/api/auth/register", json=account)
    session = db.scalar(select(AuthSession))
    session.expires_at = datetime.now(timezone.utc) - timedelta(minutes=1)
    db.commit()
    assert client.get("/api/auth/me").status_code == 401


def test_csrf_header_and_origin_checks(client, account):
    assert client.post("/api/auth/register", json=account, headers={"X-CSRF-Protection": ""}).status_code == 403
    assert client.post("/api/auth/register", json=account, headers={"Origin": "https://evil.example"}).status_code == 403
    assert client.post("/api/auth/logout", headers={"Origin": "null"}).status_code == 403
    assert client.post("/api/auth/register", json=account).status_code == 201


def test_cors_rejects_untrusted_preflight(client):
    response = client.options("/api/auth/login", headers={
        "Origin": "https://evil.example", "Access-Control-Request-Method": "POST",
        "Access-Control-Request-Headers": "X-CSRF-Protection,Content-Type",
    })
    assert response.status_code == 400
    assert "access-control-allow-origin" not in response.headers


def test_cors_accepts_configured_origin(client):
    response = client.options("/api/auth/login", headers={
        "Origin": "http://testserver", "Access-Control-Request-Method": "POST",
        "Access-Control-Request-Headers": "X-CSRF-Protection,Content-Type",
    })
    assert response.status_code == 200
    assert response.headers["access-control-allow-origin"] == "http://testserver"


@pytest.mark.parametrize("update", [{"password": "short"}, {"password": "x" * 129}, {"email": "bad"}, {"name": "  "}])
def test_registration_validation_does_not_echo_passwords(client, account, update):
    payload = {**account, **update}
    response = client.post("/api/auth/register", json=payload)
    assert response.status_code == 422
    assert payload["password"] not in response.text
    assert all("input" not in error for error in response.json()["detail"])


def test_rate_limit_is_shared_across_clients(account, monkeypatch):
    # No cookie/client state can bypass the PostgreSQL counter.
    # Keep the test within one window even if it starts at a real window boundary.
    instant = int(datetime.now(timezone.utc).timestamp()) + 300
    monkeypatch.setattr(rate_limit, "time", SimpleNamespace(time=lambda: instant))
    for _ in range(20):
        with TestClient(app, headers={"X-CSRF-Protection": "1"}) as browser:
            assert browser.post("/api/auth/login", json=credentials(account)).status_code == 401
    with TestClient(app, headers={"X-CSRF-Protection": "1"}) as browser:
        response = browser.post("/api/auth/login", json=credentials(account))
    assert response.status_code == 429
    assert int(response.headers["retry-after"]) > 0
