import os

import pytest
from alembic import command
from alembic.config import Config
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.engine import make_url

test_url = os.environ.get("TEST_DATABASE_URL")
if not test_url or not (make_url(test_url).database or "").endswith("_test"):
    raise RuntimeError("Set TEST_DATABASE_URL to a disposable PostgreSQL database ending in _test.")

# Set these before app modules initialize their settings/engine.
os.environ["DATABASE_URL"] = test_url
os.environ["JWT_SECRET"] = "test-only-jwt-signing-secret-at-least-thirty-two-bytes"
os.environ["ALLOWED_ORIGINS"] = '["http://testserver"]'
os.environ["COOKIE_SECURE"] = "false"

from app.database import engine, SessionLocal  # noqa: E402
from app.main import app  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def migrate():
    command.upgrade(Config("alembic.ini"), "head")
    yield
    engine.dispose()


@pytest.fixture(autouse=True)
def clean_database(migrate):
    # Only the explicitly guarded, disposable _test database is cleared.
    with engine.begin() as connection:
        connection.execute(text("TRUNCATE auth_sessions, users, rate_limits CASCADE"))


@pytest.fixture
def client():
    with TestClient(app, headers={"X-CSRF-Protection": "1", "Origin": "http://testserver"}) as client:
        yield client


@pytest.fixture
def db():
    with SessionLocal() as db:
        yield db


@pytest.fixture
def account():
    return {"name": "Alex Morgan", "email": "alex@example.com", "password": "a-long-test-passphrase"}
