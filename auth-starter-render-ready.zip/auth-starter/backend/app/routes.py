from datetime import datetime, timezone
from uuid import UUID, uuid4

from fastapi import APIRouter, HTTPException, Request, Response
from jwt.exceptions import InvalidTokenError
from sqlalchemy import delete, select
from sqlalchemy.exc import IntegrityError

from .config import get_settings
from .dependencies import CurrentSession, CurrentUser, Db
from .models import AuthSession, User
from .rate_limit import enforce_rate_limit
from .schemas import Credentials, RegisterInput, SessionOut, UserOut
from .security import COOKIE_NAME, DUMMY_HASH, decode_token, issue_token, password_hash

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


def revoke_cookie_session(request: Request, db: Db):
    """Revoke a valid previous browser session; expired tokens need no action."""
    token = request.cookies.get(COOKIE_NAME)
    if token:
        try:
            claims = decode_token(token)
        except InvalidTokenError:
            return
        db.execute(delete(AuthSession).where(
            AuthSession.id == UUID(claims["jti"]),
            AuthSession.user_id == UUID(claims["sub"]),
        ))


def start_session(user: User, request: Request, response: Response, db: Db) -> SessionOut:
    settings = get_settings()
    revoke_cookie_session(request, db)
    db.execute(delete(AuthSession).where(AuthSession.expires_at <= datetime.now(timezone.utc)))
    session_id = uuid4()
    token, expires = issue_token(user.id, session_id)
    db.add(AuthSession(id=session_id, user_id=user.id, expires_at=expires))
    db.commit()
    response.set_cookie(
        COOKIE_NAME, token, httponly=True, secure=settings.cookie_secure,
        samesite="lax", path="/api", max_age=settings.jwt_ttl_minutes * 60,
        expires=expires,
    )
    return SessionOut(user=UserOut.model_validate(user), expires_at=expires)


@router.post("/register", response_model=SessionOut, status_code=201)
def register(body: RegisterInput, request: Request, response: Response, db: Db):
    enforce_rate_limit(db, request, "register")
    user = User(
        name=body.name, email=str(body.email).lower(),
        password_hash=password_hash.hash(body.password),
    )
    db.add(user)
    try:
        # Unique email is enforced by PostgreSQL, including concurrent requests.
        db.flush()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="An account with this email already exists.") from None
    return start_session(user, request, response, db)


@router.post("/login", response_model=SessionOut)
def login(body: Credentials, request: Request, response: Response, db: Db):
    enforce_rate_limit(db, request, "login")
    user = db.scalar(select(User).where(User.email == str(body.email).lower()))
    valid, updated_hash = password_hash.verify_and_update(
        body.password, user.password_hash if user else DUMMY_HASH,
    )
    if user is None or not valid:
        raise HTTPException(status_code=401, detail="Email or password is incorrect.")
    if updated_hash:
        user.password_hash = updated_hash
    return start_session(user, request, response, db)


@router.get("/me", response_model=SessionOut)
def me(user: CurrentUser, session: CurrentSession):
    return SessionOut(user=UserOut.model_validate(user), expires_at=session.expires_at)


@router.post("/logout", status_code=204)
def logout(request: Request, response: Response, db: Db):
    revoke_cookie_session(request, db)
    db.commit()
    response.delete_cookie(
        COOKIE_NAME, path="/api", httponly=True,
        secure=get_settings().cookie_secure, samesite="lax",
    )
