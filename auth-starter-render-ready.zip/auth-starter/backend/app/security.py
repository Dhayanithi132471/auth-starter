from datetime import datetime, timedelta, timezone
from uuid import UUID

import jwt
from jwt.exceptions import InvalidTokenError
from pwdlib import PasswordHash

from .config import get_settings

COOKIE_NAME = "auth_access"
password_hash = PasswordHash.recommended()
# Unknown accounts still perform a password verification to reduce timing leaks.
DUMMY_HASH = password_hash.hash("dummy-password-used-only-for-timing")


def issue_token(user_id: UUID, session_id: UUID) -> tuple[str, datetime]:
    settings = get_settings()
    now = datetime.now(timezone.utc)
    expires = now + timedelta(minutes=settings.jwt_ttl_minutes)
    payload = {
        "sub": str(user_id), "jti": str(session_id), "type": "access",
        "iat": now, "nbf": now, "exp": expires,
        "iss": settings.jwt_issuer, "aud": settings.jwt_audience,
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256"), expires


def decode_token(token: str) -> dict:
    settings = get_settings()
    claims = jwt.decode(
        token, settings.jwt_secret, algorithms=["HS256"],
        issuer=settings.jwt_issuer, audience=settings.jwt_audience,
        options={"require": ["sub", "jti", "type", "iat", "nbf", "exp", "iss", "aud"]},
    )
    if claims["type"] != "access":
        raise InvalidTokenError("Wrong token type")
    try:
        UUID(claims["sub"])
        UUID(claims["jti"])
    except (ValueError, TypeError, AttributeError) as exc:
        raise InvalidTokenError("Malformed token identifiers") from exc
    return claims
