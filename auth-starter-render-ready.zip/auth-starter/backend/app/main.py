from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text

from .config import get_settings
from .dependencies import CurrentUser, Db
from .routes import router

settings = get_settings()
app = FastAPI(title="Auth Starter API", version="1.0.0", docs_url="/api/docs", openapi_url="/api/openapi.json", redoc_url=None)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "X-CSRF-Protection"],
)


@app.middleware("http")
async def browser_security(request: Request, call_next):
    # A custom header forces browser preflight on cross-origin requests. Exact
    # Origin checks additionally protect login/logout and all future mutations.
    if request.method not in {"GET", "HEAD", "OPTIONS"}:
        origin = request.headers.get("origin")
        if (request.headers.get("x-csrf-protection") != "1"
                or (origin is not None and origin not in settings.allowed_origins)):
            response = JSONResponse(status_code=403, content={"detail": "Request origin could not be verified."})
        else:
            response = await call_next(request)
    else:
        response = await call_next(request)
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    return response


@app.exception_handler(RequestValidationError)
async def validation_error(request: Request, exc: RequestValidationError):
    # Never echo Pydantic's input field: it can contain a submitted password.
    return JSONResponse(status_code=422, content={"detail": [
        {"loc": list(error["loc"]), "msg": error["msg"], "type": error["type"]}
        for error in exc.errors()
    ]})


@app.get("/api/health", tags=["Health"])
def health(db: Db):
    db.execute(text("SELECT 1"))
    return {"status": "ok"}


@app.get("/api/private", tags=["Example protected route"])
def private(user: CurrentUser):
    return {"message": f"Welcome, {user.name}. This response came from a protected API route."}


app.include_router(router)
