from datetime import datetime, timezone
from typing import Annotated
from uuid import UUID

from fastapi import Depends, HTTPException, Request
from jwt.exceptions import InvalidTokenError
from sqlalchemy.orm import Session

from .database import get_db
from .models import AuthSession, User
from .security import COOKIE_NAME, decode_token

Db = Annotated[Session, Depends(get_db)]


def current_session(request: Request, db: Db) -> AuthSession:
    token = request.cookies.get(COOKIE_NAME)
    unauthorized = HTTPException(status_code=401, detail="Please sign in to continue.")
    if not token:
        raise unauthorized
    try:
        claims = decode_token(token)
    except InvalidTokenError:
        raise unauthorized from None
    session = db.get(AuthSession, UUID(claims["jti"]))
    if (session is None or str(session.user_id) != claims["sub"]
            or session.expires_at <= datetime.now(timezone.utc)):
        raise unauthorized
    return session


CurrentSession = Annotated[AuthSession, Depends(current_session)]


def current_user(db: Db, session: CurrentSession) -> User:
    user = db.get(User, session.user_id)
    if user is None:
        raise HTTPException(status_code=401, detail="Please sign in to continue.")
    return user


CurrentUser = Annotated[User, Depends(current_user)]
