from functools import lru_cache
from pathlib import Path

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=Path(__file__).resolve().parents[2] / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    database_url: str
    jwt_secret: str = Field(min_length=32)
    jwt_ttl_minutes: int = Field(default=30, ge=1, le=1440)
    jwt_issuer: str = "auth-starter"
    jwt_audience: str = "auth-starter-web"
    cookie_secure: bool = False  # Set true behind HTTPS outside localhost.
    allowed_origins: list[str] = ["http://localhost:8080", "http://localhost:5173"]

    @field_validator("database_url")
    @classmethod
    def postgres_only(cls, value: str) -> str:
        if not value.startswith("postgresql+psycopg://"):
            raise ValueError("DATABASE_URL must use postgresql+psycopg://")
        return value

    @field_validator("allowed_origins")
    @classmethod
    def exact_origins(cls, values: list[str]) -> list[str]:
        from urllib.parse import urlsplit
        if not values:
            raise ValueError("At least one allowed origin is required")
        for origin in values:
            parsed = urlsplit(origin)
            if (parsed.scheme not in {"http", "https"} or not parsed.netloc
                    or parsed.path or parsed.query or parsed.fragment or "*" in origin
                    or parsed.username or parsed.password):
                raise ValueError("Use exact HTTP(S) origins without paths or wildcards")
        return values


@lru_cache
def get_settings() -> Settings:
    return Settings()
