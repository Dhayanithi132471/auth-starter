"""Atomic PostgreSQL fixed-window limits shared by all API workers."""
from datetime import datetime, timezone
import hashlib
import hmac
import time

from fastapi import HTTPException, Request
from sqlalchemy import delete
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from .config import get_settings
from .models import RateLimit


def enforce_rate_limit(db: Session, request: Request, action: str):
    window = 300  # Five minutes; applies to all attempts, including successes.
    limit = 10 if action == "register" else 20
    current = int(time.time())
    end = (current // window + 1) * window
    address = request.client.host if request.client else "unknown"
    digest = hmac.new(
        get_settings().jwt_secret.encode(), address.encode(), hashlib.sha256,
    ).hexdigest()
    key = f"{action}:{current // window}:{digest}"
    expires = datetime.fromtimestamp(end, timezone.utc)
    db.execute(delete(RateLimit).where(RateLimit.expires_at <= datetime.now(timezone.utc)))
    statement = insert(RateLimit).values(key=key, hits=1, expires_at=expires)
    statement = statement.on_conflict_do_update(
        index_elements=[RateLimit.key], set_={"hits": RateLimit.hits + 1},
        where=RateLimit.hits < limit,
    ).returning(RateLimit.hits)
    hit = db.execute(statement).scalar_one_or_none()
    db.commit()
    if hit is None:
        raise HTTPException(
            status_code=429, detail="Too many attempts. Please try again shortly.",
            headers={"Retry-After": str(max(1, end - current))},
        )
