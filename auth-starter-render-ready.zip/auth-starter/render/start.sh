#!/bin/sh
set -eu

cd /app

alembic upgrade head

uvicorn app.main:app --host 127.0.0.1 --port 8000 --proxy-headers --forwarded-allow-ips='*' &
BACKEND_PID=$!

cleanup() {
  kill "$BACKEND_PID" 2>/dev/null || true
}
trap cleanup INT TERM EXIT

# nginx's official image expands /etc/nginx/templates/*.template using envsubst.
nginx -g 'daemon off;'
